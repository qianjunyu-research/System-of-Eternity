﻿# File Manifest - SOE Paper-Design / Public-Archive Closeout

| File | Bytes | SHA-256 |
|---|---:|---|
| `SOE_Paper_Design_Public_Archive_Closeout_2026-06-01.md` | 2189 | `099d612accf1f6481a47461a55b24d0f23bcf5845512ed2e97ab6a6516d37d83` |

This manifest intentionally excludes itself from the hash table.
