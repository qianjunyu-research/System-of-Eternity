﻿# File Manifest - SOE v0.8 Existing Publication Registry Correction

| File | Bytes | SHA-256 |
|---|---:|---|
| `SOE_v0_8_Existing_Publication_Registry_Correction_2026-06-01.md` | 2041 | `b509f83663c3ae271f2ae24c34cb8a25c6f9676eaa5c134ad8336e223ea8c8b8` |

This manifest intentionally excludes itself from the hash table.
