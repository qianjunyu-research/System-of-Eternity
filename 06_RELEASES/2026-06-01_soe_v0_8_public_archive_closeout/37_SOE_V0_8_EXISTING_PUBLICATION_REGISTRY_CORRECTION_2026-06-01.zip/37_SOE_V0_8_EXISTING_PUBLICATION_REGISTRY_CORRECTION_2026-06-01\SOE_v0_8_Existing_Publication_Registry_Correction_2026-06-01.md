﻿# SOE v0.8 Existing Publication Registry Correction

Date: 2026-06-01

Purpose: correct the local next-step registry after confirming that the SGS/TGS manuscript and supplementary evidence package were already published on Zenodo before the three v0.8 structure new-version uploads.

## Published Records

| Record | Zenodo link | Local status |
|---|---|---|
| SOE architecture / evidence-boundary / future-concern registry working paper | https://zenodo.org/records/20471399 | Browser-verified. Published May 31, 2026, Version 0.7, Working paper, author QianJun Yu, CC BY 4.0. Description explicitly includes First Grand Simulation, SGS, TGS evidence, and future-concern registry boundaries. |
| Supplementary dataset / evidence package linked from working paper | https://zenodo.org/records/20471382 | Zenodo browser check returned rate-limit during this registry pass, but record is linked from the verified 20471399 page as supplementary dataset DOI 10.5281/zenodo.20471382. |

## Correction

Do not treat SGS/TGS result publication as a remaining unpublished task unless QianJun Yu separately decides to issue a newer version.

The current public chain already includes:

1. SGS/TGS and future-concern manuscript/evidence-boundary working paper.
2. Supplementary SGS/TGS/evidence dataset package.
3. Three updated SOE v0.8 structure public archival versions:
   - Meta-Governance Framework
   - Governance Architecture
   - Operation Layer

## Remaining Likely Publication Gap

The remaining likely publication gap is not SGS/TGS. It is the standalone fiction/nonfiction failure-pattern harvest paperwork, if QianJun Yu wants those research-harvest materials archived separately rather than only referenced through the v0.7/v0.8 working-paper chain.

## Boundary

This correction is an archive/registry note only. It does not authorize new publication, new simulation execution, tabletop execution, pilot work, deployment, empirical validation, real-world node recognition, cryptographic implementation, or Operation Layer freeze.
