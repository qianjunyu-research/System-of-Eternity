# SOE v0.8 Public Archival Exports - Zenodo New-Version Guide

Folder:

`35_SOE_V0_8_PUBLIC_ARCHIVAL_NEW_VERSION_EXPORTS_2026-06-01`

Purpose: local upload-ready exports for **new versions of existing Zenodo records**. These are not intended as new standalone deposits unless QianJun Yu separately decides otherwise.

## Upload Rule

Use Zenodo's **New version** button on each existing record:

1. Existing Meta-Governance / Civilizational Governance Framework record
   - Upload:
     - `System_of_Eternity_Meta_Governance_Framework_v4_4_v0_8_Public_Archival_Version_2026-06-01.docx`
     - `System_of_Eternity_Meta_Governance_Framework_v4_4_v0_8_Public_Archival_Version_2026-06-01.pdf`

2. Existing SOE Governance Architecture record
   - Upload:
     - `SOE_Governance_Architecture_v0_5_2_v0_8_Public_Archival_Version_2026-06-01.docx`
     - `SOE_Governance_Architecture_v0_5_2_v0_8_Public_Archival_Version_2026-06-01.pdf`

3. Existing SOE Operation Layer record
   - Upload:
     - `SOE_Operation_Layer_v0_1_3_v0_8_Public_Archival_Version_2026-06-01.docx`
     - `SOE_Operation_Layer_v0_1_3_v0_8_Public_Archival_Version_2026-06-01.pdf`

## Shared Metadata

Creator / author:

`QianJun Yu`

License:

`Creative Commons Attribution 4.0 International (CC BY 4.0)`

Version:

`v0.8 public archival version`

Resource type:

Use the same record type as the existing Zenodo item unless QianJun Yu decides to change it. For these three structure documents, "Working paper" or "Report" is acceptable depending on the existing record.

Keywords:

`System of Eternity`; `civilizational governance`; `governance architecture`; `meta-governance`; `operation layer`; `architecture-model simulation`; `future concern registry`; `anti-scenario governance`

## Boundary Sentence For Descriptions

Use this sentence in each description:

`This public archival version records an architecture and governance-structure update. It does not present pilot readiness, deployment readiness, empirical validation, real-world node recognition, cryptographic readiness, legal enforceability, or an Operation Layer freeze.`

## Suggested Descriptions

### Meta-Governance v4.4 / v0.8

`This v0.8 public archival version updates the System of Eternity Meta-Governance Framework with the accepted v0.8 integration line, including evidence-boundary discipline, source hierarchy, governance null-result handling, non-autonomy rules for review cycles, and the future-concern intake pathway. This public archival version records an architecture and governance-structure update. It does not present pilot readiness, deployment readiness, empirical validation, real-world node recognition, cryptographic readiness, legal enforceability, or an Operation Layer freeze.`

### Governance Architecture v0.5.2 / v0.8

`This v0.8 public archival version updates the SOE Governance Architecture as the C00-C09 canonical structure line, incorporating accepted SGS/TGS and fiction/nonfiction failure-pattern findings under architecture-model boundaries. It includes C09 gate logic, Anti-Scenario Registry routing, coverage-locking rules, C07/C06 boundary handling, and carried open cautions. This public archival version records an architecture and governance-structure update. It does not present pilot readiness, deployment readiness, empirical validation, real-world node recognition, cryptographic readiness, legal enforceability, or an Operation Layer freeze.`

### Operation Layer v0.1.3 / v0.8

`This v0.8 public archival version updates the SOE Operation Layer as an integrated architecture-control layer, incorporating accepted OLTS, SGS/TGS, and failure-pattern findings under architecture-model boundaries. It preserves the nine component families, C07 routing spine, OL-RTC review cycle, TOE-01 terms-of-engagement requirement, traceability controls, and active cautions including TGS-S27 and TGS-S44. This public archival version records an architecture and governance-structure update. It does not present pilot readiness, deployment readiness, empirical validation, real-world node recognition, cryptographic readiness, legal enforceability, or an Operation Layer freeze.`

## Upload Checklist

- Confirm you are on the existing record page.
- Click **New version**, not **New upload**.
- Remove the prior file set only if Zenodo requires replacing files for the new version.
- Upload both DOCX and PDF for that structure.
- Preserve or update related identifiers as appropriate for the existing record.
- Paste the boundary sentence into the description.
- Set license to CC BY 4.0 if not already set.
- Preview files and metadata before publishing the new version.

## Local Verification

DOCX text scan confirmed no remaining:

- `not public-release authorized`
- `Zenodo upload`
- `DOI creation`
- `structure-freeze candidate`
- `first-pass readable draft`
- `Codex review`

PDF exports were generated locally with LibreOffice and spot-checked on first pages plus changed pages.
