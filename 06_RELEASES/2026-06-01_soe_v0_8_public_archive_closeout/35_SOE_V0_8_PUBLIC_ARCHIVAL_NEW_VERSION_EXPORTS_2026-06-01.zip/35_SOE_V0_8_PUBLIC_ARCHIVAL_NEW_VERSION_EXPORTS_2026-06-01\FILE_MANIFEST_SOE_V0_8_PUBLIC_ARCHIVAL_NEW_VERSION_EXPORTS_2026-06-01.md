# File Manifest - SOE v0.8 Public Archival New-Version Exports

Folder:

`35_SOE_V0_8_PUBLIC_ARCHIVAL_NEW_VERSION_EXPORTS_2026-06-01`

Generated: 2026-06-01

## Files

| File | Bytes | SHA-256 |
|---|---:|---|
| `README_ZENODO_NEW_VERSION_UPLOAD_GUIDE_2026-06-01.md` | 4957 | `a0c15a81e83cfe9611e3bb48511f7b70e8a67fd381e54e3319506314cf4ea14f` |
| `SOE_Governance_Architecture_v0_5_2_v0_8_Public_Archival_Version_2026-06-01.docx` | 136794 | `ffdf6b3ff1edc213f1f29bc16a6fa0b9f1d3ca19f7238345178985518981795e` |
| `SOE_Governance_Architecture_v0_5_2_v0_8_Public_Archival_Version_2026-06-01.pdf` | 1532366 | `791cdc64a9bd2a4ce4ce9c97ffbad889371627d8c548d4216f98acc59c4e188b` |
| `SOE_Operation_Layer_v0_1_3_v0_8_Public_Archival_Version_2026-06-01.docx` | 53930 | `616554478f41ae6444588ee7832a9225f1536452160c8e741eef3ed6f65f392a` |
| `SOE_Operation_Layer_v0_1_3_v0_8_Public_Archival_Version_2026-06-01.pdf` | 692044 | `8e07322db764fc5da3aa09744f40317fe6262691c680905666603d0c952c33b2` |
| `System_of_Eternity_Meta_Governance_Framework_v4_4_v0_8_Public_Archival_Version_2026-06-01.docx` | 3144357 | `82bfa9eb0e8dab908522c618652fed033ccf12849988706f5a584424dee5d5b9` |
| `System_of_Eternity_Meta_Governance_Framework_v4_4_v0_8_Public_Archival_Version_2026-06-01.pdf` | 2648791 | `b7dc4223dbbc471c41c98f0673c3cdc3d77c3a747a2b519bb0a48603bc3dbba9` |

## Manifest Rule

This manifest intentionally excludes itself from the hash table.

## Boundary

These are public archival exports for Zenodo **New version** upload to existing SOE structure records. Publication of these files does not authorize simulation execution, tabletop execution, pilot work, deployment, empirical validation, real-world node recognition, cryptographic implementation, legal enforceability, or Operation Layer freeze.
