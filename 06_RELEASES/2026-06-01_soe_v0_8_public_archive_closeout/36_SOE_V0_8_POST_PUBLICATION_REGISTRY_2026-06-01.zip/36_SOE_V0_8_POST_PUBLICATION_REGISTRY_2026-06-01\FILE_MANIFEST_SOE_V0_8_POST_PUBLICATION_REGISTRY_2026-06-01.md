﻿# File Manifest - SOE v0.8 Post-Publication Registry

Folder:

`36_SOE_V0_8_POST_PUBLICATION_REGISTRY_2026-06-01`

| File | Bytes | SHA-256 |
|---|---:|---|
| `SOE_v0_8_Post_Publication_Registry_Note_2026-06-01.md` | 1985 | `c5c8a1ec2dcb3b3b9a9e774159ca9a68e76892201948e87349b8af7b65482989` |

This manifest intentionally excludes itself from the hash table.
