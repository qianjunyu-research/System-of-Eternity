﻿# SOE v0.8 Post-Publication Registry Note

Date: 2026-06-01

Status: three SOE structure records updated publicly through Zenodo new-version workflow.

## Published Records

| Structure | Zenodo record | Status |
|---|---|---|
| SOE Meta-Governance Framework v4.4 / v0.8 public archival version | https://zenodo.org/records/20499592 | Published link provided by QianJun Yu; browser verification was rate-limited during local registry creation. |
| SOE Governance Architecture v0.5.2 / v0.8 public archival version | https://zenodo.org/records/20499579 | Published link provided by QianJun Yu; browser verification was rate-limited during local registry creation. |
| SOE Operation Layer v0.1.3 / v0.8 public archival version | https://zenodo.org/records/20499518 | Browser-verified: record page opened, Version 0.1.3, author QianJun Yu, CC BY 4.0, public archival DOCX/PDF files present. |

## Source Basis

The public archival exports were derived from the accepted internal DOCX structure baseline:

`34_SOE_V0_8_FINAL_DOCX_STRUCTURE_FREEZE_CANDIDATES_PATCHED_2026-06-01`

The upload-ready public archival files were prepared in:

`35_SOE_V0_8_PUBLIC_ARCHIVAL_NEW_VERSION_EXPORTS_2026-06-01`

## Boundary Preserved

These Zenodo records are public archival architecture documents. They do not claim pilot readiness, deployment readiness, empirical validation, real-world node recognition, cryptographic readiness, legal enforceability, simulation execution authorization, tabletop execution authorization, or Operation Layer freeze.

## Registry Consequence

The internal v0.8 integrated structure update is now publicly archived across the three live SOE structure surfaces:

- Meta-Governance Framework
- Governance Architecture
- Operation Layer

This closes the v0.8 structure-body publication step. It does not close the remaining publication chain for SGS/TGS result papers or fiction/nonfiction failure-pattern research unless those are separately packaged and published.
